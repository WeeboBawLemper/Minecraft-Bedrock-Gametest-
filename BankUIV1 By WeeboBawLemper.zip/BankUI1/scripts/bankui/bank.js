/*
Creator: WeeboBawLemper
Discord: Weebo Baw Lemper#1466
Youtube: WeeboBawLemper
https://www.youtube.com/@weebobawlemper

I learn From : Snaky
*/





import { world,system } from "@minecraft/server";
import { ActionFormData,ModalFormData } from "@minecraft/server-ui";
system.events.beforeWatchdogTerminate.subscribe(data => {
  data.cancel = true;
});

function setTickTimeout(callback, tick){
    let ticks = 0
    let TickCallBack = system.runInterval(() => {
        ticks += 1
        
        if(ticks == tick){
            callback()
            system.runInterval(TickCallBack)
        }
    })
}

function getScore(entity, objective) {
   try {
       return world.scoreboard.getObjective(objective).getScore(entity.scoreboard);
   } catch (error) {
       return 0;
   }
}

//untuk format Money
 function metricNumbers(value) {
    const types = ["", "k", "M", "B", "T", "P", "E", "Z", "Y"];
    const selectType = (Math.log10(value) / 3) | 0;
    if (selectType == 0) return value;
    let scaled = value / Math.pow(10, selectType * 3);
    return scaled.toFixed(1) + types[selectType];
  }  

system.runInterval(() => {
     for (let player of world.getPlayers()) {
           if (player.hasTag("bank:ui")) {
               bankui(player);
               player.removeTag(`bank:ui`)
           }
       }
});
world.events.entityHit.subscribe((data) => {
  if (data.hitBlock) return;
  if (data.hitEntity.hasTag("bank:ui")) {
    let player = data.entity;
    try {
      player.runCommandAsync(`playsound note.bell @s`);
      bankui(player);
    } catch (e) {
      bankui(player);
    }
  }
});

export function bankui(player) {
      const bankui = new ActionFormData()
      bankui.title("§l§1BANK UI")
      bankui.body(`§6Welcome,\n§r§7Money Balance §f: §f$ §a${metricNumbers(getScore(player, "money"))}\n§7Bank Balance §f: §f$ §a${(getScore(player, "bank"))}\n`)
      bankui.button("§l§0Withdraw\n§r§o§7Click to Open..", "textures/ui/icon_best3")
      bankui.button("§l§0Deposite\n§r§o§7Click to Open..", "textures/ui/recipe_book_icon")
      bankui.button("§l§0Transfer\n§r§o§7Click to Open..", "textures/ui/trade_icon")
      bankui.show(player).then((res) => {
        if(res.selection === 0) {
          const wdr = new ModalFormData()
          wdr.title("§l§0Withdraw")
          wdr.textField(`\n§fBank Balance §f: §f$ §a${(getScore(player, "bank"))}`, `§7Input Here!`)
          wdr.show(player).then((res) => {
            let playerscore = getScore(player, "bank")
            if ( Number(playerscore) < Number(res.formValues[0]) ) {
              player.sendMessage(`§8[§bBank§8] §4Your Balance Is Not Enough!`)
            } else {
              player.sendMessage(`§8[§bBank§8] §aSuccessful Withdraw §f$ §e${res.formValues[0]}`)
              player.runCommandAsync(`playsound note.bell @s`)
              player.runCommandAsync(`scoreboard players add @s money ${res.formValues[0]}`)
              player.runCommandAsync(`scoreboard players remove @s bank ${res.formValues[0]}`)
            }
          });
        }
        if(res.selection === 1) {
          const dp = new ModalFormData()
          dp.title("§l§0Deposite")
          dp.textField(`\n§fMoney Balance §f$ §a${(getScore(player, "money"))}`, `Input Here!`)
          dp.show(player).then((res) => {
            let playerscore = getScore(player, "money")
            if ( Number(playerscore) < Number(res.formValues[0]) ) {
              player.sendMessage(`§8[§bBank§8] §4Your Money Is Not Enough!`)
            } else {
              player.sendMessage(`§8[§bBank§8] §aSuccessful Saving §f$ §e${res.formValues[0]}`)
              player.runCommandAsync(`playsound note.bell @s`)
              player.runCommandAsync(`scoreboard players remove @s money ${res.formValues[0]}`)
              player.runCommandAsync(`scoreboard players add @s bank ${res.formValues[0]}`)
            }
          });
        }
        if(res.selection === 2) {
          let fm = new ModalFormData()
          var playerObjects = []
          var operations = []
          var players = world.getPlayers()
          for (let playerr of players) {
            operations.push(playerr.name)
            playerObjects.push(playerr)
          }
          const trf = new ModalFormData()
          trf.title("§l§0Transfer")
          trf.dropdown(`\n§fBank Balance §f: §f$ §a${(getScore(player, "bank"))}\n§fSelect Player`,operations,0)
          trf.textField(`§fAmount You Want To Send :`, `Input Here!`)
          trf.show(player).then((res) => {
            let target = operations[res.formValues[0]]
            let playerscore = getScore(player, "bank")
            if( Number(playerscore) < Number(res.formValues[1]) ) {
              player.sendMessage(`§8[§bBank§8] §4Your Balance Is Not Enough!`)
            } else {
              player.sendMessage(`§8[§bBank§8] §aSuccess in Sending Money To Account §e${target} §aAmount §f$ ${res.formValues[1]}`)
              player.runCommandAsync(`scoreboard players add "${target}" bank ${res.formValues[1]}`)
              player.runCommandAsync(`scoreboard players remove @s bank ${res.formValues[1]}`)
              player.runCommandAsync(`tellraw ${target} {"rawtext":[{"text":"§8[§bBank§8] §aYou Have Been Transferred From §e${player.name} §aAmount §f$ ${res.formValues[1]}"}]}`)
              player.runCommandAsync(`playsound note.bell @s`)
            }
          });
       }
      }
    )
  }

  world.events.beforeChat.subscribe((msg) => {
    let player = msg.sender
    if(msg.message.startsWith("+bankinfo")) {
      msg.cancel = true
      player.sendMessage(`§8[§bBank Information§8] §e\n +bankregister < to create bank account >\n +bank < to open bank ui >`)
    }
    if(msg.message.startsWith("+bankregister")) {
      msg.cancel = true
      player.addTag(`mbank`)
      player.sendMessage(`§8[§bBank§8] §eSuccesfully Create M-Bank`)
    }
    if(msg.message.startsWith("+bank")) {
      msg.cancel = true
      if(player.hasTag("mbank")) {
        player.sendMessage(`§8[§bBank§8] §ePlease wait 3 seconds and close this message to bring up the UI`)
        setTickTimeout(() => {
          player.addTag(`bank:ui`)}, 70);
        } else {
          player.sendMessage(`§8[§bBank§8] §4You Dont Have Bank Account!`)
        }
      }
  });
