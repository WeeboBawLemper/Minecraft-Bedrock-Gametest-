
import "./bankui/bank.js"
//To add another script, it must be imported here first
//Example: import "./example.js"

/*
----------------------------------
Creator: Mafly
Discord: Maplii#9957
Youtube: MaFly
https://www.youtube.com/c/MaFly16

Website:
https://mafly.xyz/
----------------------------------
*/